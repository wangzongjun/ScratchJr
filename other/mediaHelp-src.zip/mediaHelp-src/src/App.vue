<!--
 * @Author: your name
 * @Date: 2021-04-05 17:32:43
 * @LastEditTime: 2021-04-11 18:08:58
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /work/education_game/src/App.vue
-->
<template>
  <div id="app">
    <div class="app__right">
      <!-- <header class="header"></header> -->
      <div class="content">
        <div class="app__content">
          <router-view />
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="less">
html,
body,
#app {
  margin: 0;
  padding: 0;
  height: 100%;
}
.app__right {
  background: #f0f2f6;
  height: 100%;
  box-sizing: border-box;

  .header {
    height: 30px;
    background: #fff;
  }
  .content {
    height: 100%;
    box-sizing: border-box;

    .app__content {
      box-sizing: border-box;
      height: 100%;
      background: #fff;
      padding: 10px;
    }
  }
}
</style>
