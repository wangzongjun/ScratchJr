/*
 * @Author: your name
 * @Date: 2020-11-26 15:07:37
 * @LastEditTime: 2021-04-11 11:32:43
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /wolfberry-platform/src/plugins/element.ts
 */
import Vue from 'vue'
import {
  Button,
  Menu,
  Submenu,
  MenuItem,
  Dropdown,
  DropdownMenu,
  DropdownItem,
  MessageBox,
  Dialog,
  Table,
  TableColumn,
  Input,
  Select,
  Form,
  CheckboxGroup,
  Checkbox,
  FormItem,
  Option,
  Row,
  Col,
  RadioGroup,
  Radio,
  Tree,
  Upload,
  Pagination,
  RadioButton,
  Message
} from 'element-ui'
Vue.use(Upload)
Vue.use(RadioButton)
Vue.use(Pagination)
Vue.use(Option)
Vue.use(Form)
Vue.use(FormItem)
Vue.use(Menu)
Vue.use(Button)
Vue.use(Submenu)
Vue.use(MenuItem)
Vue.use(Dropdown)
Vue.use(DropdownMenu)
Vue.use(DropdownItem)
Vue.use(Dialog)
Vue.use(Table)
Vue.use(TableColumn)
Vue.use(Input)
Vue.use(Select)
Vue.use(Form)
Vue.use(FormItem)
Vue.use(CheckboxGroup)
Vue.use(Checkbox)
Vue.use(Row)
Vue.use(Col)
Vue.use(RadioGroup)
Vue.use(Radio)
Vue.use(Tree)
Vue.prototype.$confirm = MessageBox.confirm
Vue.prototype.$message = Message
