/*
 * @Author: your name
 * @Date: 2020-11-26 15:07:37
 * @LastEditTime: 2021-04-18 21:20:48
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /wolfberry-platform/src/api/index.ts
 */
const commonApi = require('./common/common')
module.exports = {
  ...commonApi
}
