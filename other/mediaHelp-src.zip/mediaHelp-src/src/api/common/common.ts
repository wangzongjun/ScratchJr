/*
 * @Author: your name
 * @Date: 2021-04-05 17:42:20
 * @LastEditTime: 2021-04-18 21:26:56
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /work/education_game/src/api/common/common.ts
 */
// import { Domain } from '@/util/url'
import ajax from '@/util/serve'

//获取静态数据
export const geDatasApi = () => {
  return ajax({
    method: 'get',
    url: '/media.json'
  })
}
