<!--
 * @Author: your name
 * @Date: 2021-04-05 17:32:43
 * @LastEditTime: 2021-04-05 18:16:04
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /work/education_game/src/views/Home.vue
-->
<template>
  <div></div>
</template>

<script>
export default {
  data() {
    return {}
  }
}
</script>
