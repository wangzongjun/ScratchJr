<!--
 * @Author: your name
 * @Date: 2021-04-05 18:17:51
 * @LastEditTime: 2021-04-19 08:43:44
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /education_game/src/views/control_center/components/edit.vue
-->
<template>
  <div>
    <el-form
      :model="ruleForm"
      :rules="rules"
      ref="ruleForm"
      label-width="100px"
      class="demo-ruleForm"
      size="mini"
    >
      <el-form-item label="文件名称" prop="md5">
        <el-input
          style="width: 300px"
          v-model="ruleForm.md5"
          placeholder="请输入文件名称"
          @change="handleChange"
        ></el-input>
        <el-button
          class="preview__btn"
          :disabled="!ruleForm.md5"
          type="primary"
          @click="handlePreview"
          >预览</el-button
        >
        <div v-if="imgUrl" class="prewiew__img">
          <img :src="imgUrl" />
          <div>
            <p>宽度 {{ ruleForm.width }}</p>
            <p>高度 {{ ruleForm.height }}</p>
          </div>
        </div>
      </el-form-item>
      <el-form-item label="角色名称" prop="name">
        <el-input
          v-model="ruleForm.name"
          placeholder="请输入角色名称"
        ></el-input>
      </el-form-item>
      <el-form-item label="角色分类">
        <el-input
          v-model="ruleForm.category"
          placeholder="请输入角色分类"
        ></el-input>
      </el-form-item>
      <el-form-item label="角色标签">
        <el-input
          v-model="ruleForm.tags"
          placeholder="请输入角色标签,用英文,来区分不同的标签"
        ></el-input>
      </el-form-item>
      <el-form-item class="form__item__btn">
        <el-button v-if="value !== '{}'" type="danger" @click="deleteContent"
          >删除</el-button
        >
        <el-button type="primary" @click="submitForm('ruleForm')"
          >完成</el-button
        >
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
export default {
  props: {
    datas: {
      type: Object
    },
    value: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      imgUrl: '',
      ruleForm: {
        id: new Date().getTime(),
        name: '',
        ext: '',
        md5: '',
        width: '',
        height: '',
        category: ''
      },
      rules: {
        md5: [
          { required: true, message: '文件名称为必填内容', trigger: 'blur' }
        ],
        name: [{ required: true, message: '角色名称', trigger: 'blur' }]
      }
    }
  },
  watch: {
    value() {
      this.init()
    }
  },
  mounted() {
    this.init()
  },
  methods: {
    handleChange() {
      this.$set(this.ruleForm, 'width', 0)
      this.$set(this.ruleForm, 'height', 0)
      this.$set(this.ruleForm, 'ext', '')
      this.imgUrl = ''
    },
    init() {
      if (this.value !== '{}') {
        let data = JSON.parse(this.value)
        data.tags = data.tags && data.tags.join(',')
        this.ruleForm = data
        this.handlePreview()
      }
    },
    handlePreview() {
      this.$set(this.ruleForm, 'md5', this.ruleForm.md5.trim())
      let data = this.datas
      console.error(data)
      let result = false
      data.backgrounds.forEach((element) => {
        if (
          element.md5 === this.ruleForm.md5.trim() &&
          element.id !== this.ruleForm.id
        ) {
          result = true
        }
      })
      data.sprites.forEach((element) => {
        if (
          element.md5 === this.ruleForm.md5.trim() &&
          element.id !== this.ruleForm.id
        ) {
          result = true
        }
      })

      if (result) {
        this.$message({
          type: 'error',
          message: '文件已经被创建过'
        })
        return
      }

      let img = new Image()
      let imgUrl = '/svglibrary/' + this.ruleForm.md5
      img.src = imgUrl
      let that = this
      img.onload = function () {
        that.$set(that.ruleForm, 'width', img.width)
        that.$set(that.ruleForm, 'height', img.height)
        that.$set(that.ruleForm, 'ext', that.ruleForm.md5.split('.')[1])
        that.imgUrl = imgUrl
      }
      img.onerror = () => {
        that.$set(that.ruleForm, 'width', 0)
        that.$set(that.ruleForm, 'height', 0)
        that.$set(that.ruleForm, 'ext', '')
        this.imgUrl = ''
        this.$message({
          type: 'error',
          message: '文件不存在'
        })
      }
    },
    deleteContent() {
      this.$confirm('确认删除吗？')
        .then(() => {
          this.$emit('deleteContent', this.ruleForm.id)
        })
        .catch(() => {})
    },
    submitForm(formName) {
      this.$set(
        this.ruleForm,
        'name',
        this.ruleForm.name && this.ruleForm.name.trim()
      )
      this.$set(
        this.ruleForm,
        'ext',
        this.ruleForm.ext && this.ruleForm.ext.trim()
      )
      this.$set(
        this.ruleForm,
        'md5',
        this.ruleForm.md5 && this.ruleForm.md5.trim()
      )
      this.$set(
        this.ruleForm,
        'category',
        this.ruleForm.category && this.ruleForm.category.trim()
      )
      this.$refs[formName].validate((valid) => {
        if (valid) {
          if (this.imgUrl === '') {
            this.$message({
              type: 'warning',
              message: '请先完成预览'
            })
          } else {
            let data = JSON.parse(JSON.stringify(this.ruleForm))
            let temp = data.tags && data.tags.trim().split(',')
            let r = []
            if (temp) {
              r = temp.filter(function (s) {
                return s && s.trim()
              })
            }

            data.tags = r
            this.$emit('change', data)
          }
        } else {
          console.log('error submit!!')
          return false
        }
      })
    }
  }
}
</script>

<style lang="less" scoped>
.preview__btn {
  margin-left: 15px;
}
.prewiew__img {
  img {
    width: 100px;
    height: 100px;
    margin-right: 20px;
  }
  display: flex;
}
.form__item__btn {
  text-align: right;
}
</style>
