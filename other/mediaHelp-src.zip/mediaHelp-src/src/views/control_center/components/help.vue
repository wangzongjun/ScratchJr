<!--
 * @Author: your name
 * @Date: 2021-04-11 17:08:49
 * @LastEditTime: 2021-04-20 20:25:34
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /education_game/src/views/control_center/components/help.vue
-->
<template>
  <div class="help">
    <iframe
      src="/mediaHelp.html"
      id="mobsf"
      frameborder="0"
      style="max-width: 100%"
    ></iframe>
  </div>
</template>

<script>
export default {
  data() {
    return {}
  },
  mounted() {
    /**
     * iframe-宽高自适应显示
     */
    function changeMobsfIframe() {
      const mobsf = document.getElementById('mobsf')
      const deviceWidth = document.body.clientWidth
      const deviceHeight = document.body.clientHeight
      mobsf.style.width = Number(deviceWidth) - 120 + 'px' //数字是页面布局宽度差值
      mobsf.style.height = Number(deviceHeight) - 80 + 'px' //数字是页面布局高度差
    }

    changeMobsfIframe()

    window.onresize = function () {
      changeMobsfIframe()
    }
  }
}
</script>
