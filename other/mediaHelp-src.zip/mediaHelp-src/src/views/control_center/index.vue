<!--
 * @Author: your name
 * @Date: 2021-04-05 17:32:43
 * @LastEditTime: 2021-04-20 20:23:55
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /work/education_game/src/views/Home.vue
-->
<template>
  <div class="index">
    <div class="index__header">
      <el-radio-group
        class="index__header_radio--size"
        @change="changeType"
        size="small"
        v-model="select"
      >
        <el-radio-button label="sprites">角色</el-radio-button>
        <el-radio-button label="backgrounds">背景</el-radio-button>
      </el-radio-group>
      <div class="index__header_btn">
        <el-button type="danger" size="small" @click="isShowHelp = true"
          >帮助</el-button
        >
        <el-button type="success" size="small" @click="changeDownload"
          >保存</el-button
        >
      </div>
    </div>

    <div class="index__content">
      <div class="index__content_header">
        <el-button
          type="info"
          class="index__content_header--btn"
          size="medium"
          @click="handleClick('新增角色')"
          >增加</el-button
        >
        <el-input
          placeholder="请输入搜索的内容"
          class="index__content_header--input"
          size="medium"
          @input="handleSearch"
          v-model="searchName"
        ></el-input>
      </div>
      <div class="index__content_center">
        <el-radio-group
          @change="handleChangeCategory"
          size="medium"
          v-model="category"
        >
          <el-radio-button label="-1">全部</el-radio-button>
          <el-radio-button
            :key="key"
            v-for="(item, key) of Object.keys(categoryList)"
            :label="item"
            >{{ item }}</el-radio-button
          >
        </el-radio-group>
      </div>
      <div class="index__content_bottom">
        <div
          class="index__content--item"
          v-for="(item, key) of showList"
          :key="key"
        >
          <img :src="'/svglibrary/' + item.md5" alt="" />
          <div class="index__content--name">{{ item.name }}</div>
          <div
            @click="handleClick('编辑角色', item, key)"
            class="index__content--edit"
          >
            编辑
          </div>
        </div>
        <div class="no-data" v-if="showList.length === 0">暂无数据</div>
      </div>
    </div>
    <el-dialog
      v-if="dialogVisible"
      :title="`${JSON.stringify(editContent) === '{}' ? '新增' : '修改'}${
        select === 'sprites' ? '角色' : '背景'
      }`"
      :visible.sync="dialogVisible"
      width="600px"
      :before-close="handleClose"
    >
      <Edit
        :datas="datas"
        @deleteContent="handleDelete"
        :value="JSON.stringify(editContent)"
        @change="changeValue"
        v-if="dialogVisible"
      ></Edit>
    </el-dialog>
    <el-dialog :visible.sync="isShowHelp" width="80%">
      <Help style="height: 700px; overflow-y: auto"></Help>
    </el-dialog>
  </div>
</template>

<script>
import Edit from './components/edit'
import { saveAs } from 'file-saver'
import Help from './components/help'
import { geDatasApi } from '../../api/index'
export default {
  components: {
    Edit,
    Help
  },
  data() {
    return {
      isShowHelp: false,
      category: '-1', //
      editContent: {}, //修改时候页面传入的数据
      dialogTitle: '', //dialog题目
      datas: {}, //总的数据
      searchName: '', //搜索的内容
      showLists: [], //显示的总的数据(方便搜索添加的)
      showList: [], //实际依靠渲染的数据
      select: 'sprites',
      dialogVisible: false,
      categoryList: {} //分类
    }
  },

  mounted() {
    window.addEventListener('beforeunload', (e) => this.beforeunloadHandler(e))

    this.getData()
  },
  methods: {
    beforeunloadHandler(e) {
      e = e || window.event
      if (e) {
        e.returnValue = '关闭提示'
      }
      return '关闭提示'
    },
    getData() {
      // let data = JSON.parse(JSON.stringify(require('./media.json')))
      geDatasApi().then((res) => {
        let data = JSON.parse(JSON.stringify(res))
        data.backgrounds.forEach((x, key) => {
          if (!x.id) {
            x.id = new Date().getTime() + key
          }
        })
        data.sprites.forEach((x, key) => {
          if (!x.id) {
            x.id = new Date().getTime() + key
          }
        })
        this.datas = data
        this.init()
      })
    },
    // 选择分类
    changeType() {
      this.category = '-1'
      this.init()
    },
    // 在输入框搜索内容
    handleSearch() {
      let data = this.searchName
      if (data) {
        let result = []
        this.showLists.forEach((x) => {
          if (
            x.name.indexOf(data) !== -1 ||
            (x.tags && JSON.stringify(x.tags).indexOf(data) !== -1)
          ) {
            result.push(x)
          }
        })
        this.showList = result
      } else {
        this.showList = this.showLists
      }
    },
    // 点击保存数据。下载json文件
    changeDownload() {
      let data = JSON.parse(JSON.stringify(this.datas))
      data.sprites.forEach((element) => {
        if (element.id) {
          delete element.id
        }
      })
      data.backgrounds.forEach((element) => {
        if (element.id) {
          delete element.id
        }
      })
      let blob = new Blob([JSON.stringify(data)], {
        type: 'text/plain;charset=utf-8'
      })
      saveAs(blob, 'media.json')
    },
    // 点击分类
    handleChangeCategory() {
      if (!this.categoryList[this.category]) {
        this.category = '-1'
      }
      if (this.category === '-1') {
        this.showLists = this.datas[this.select]
        this.showList = this.datas[this.select]
      } else {
        this.showList = this.categoryList[this.category]
        this.showLists = this.categoryList[this.category]
      }
      if (this.searchName !== '') {
        this.handleSearch()
      }
    },
    // 初始化数据
    init() {
      this.searchName = ''
      this.dialogVisible = false
      this.editContent = {}
      this.dialogTitle = ''
      let data = this.datas[this.select]
      let object = {}
      data.forEach((element) => {
        if (!element.category) {
          return
        }
        if (!object[element.category]) {
          object[element.category] = []
        }
        object[element.category].push(element)
      })
      this.categoryList = object
      this.handleChangeCategory()
    },
    // 关闭dialog弹窗确认窗口
    handleClose(done) {
      this.$confirm('确认关闭？')
        .then(() => {
          this.init()
          done()
        })
        .catch(() => {})
    },
    // 保存 编辑角色和创建角色的数据
    changeValue(data) {
      console.log(data, this.editContent)
      if (JSON.stringify(this.editContent) === '{}') {
        this.datas[this.select].push(data)
      } else {
        this.$set(
          this.datas[this.select],
          this.datas[this.select].findIndex((x) => x.id === data.id),
          data
        )
      }
      this.init()
    },
    // 编辑状态下点击删除
    handleDelete(id) {
      this.datas[this.select].splice(
        this.datas[this.select].findIndex((x) => x.id === id),
        1
      )
      this.init()
    },
    // 点击增加角色和编辑角色
    handleClick(name, value) {
      if (value) {
        this.editContent = value
      }
      this.dialogTitle = name
      this.dialogVisible = true
    }
  },
  destroyed() {
    window.removeEventListener('beforeunload', (e) =>
      this.beforeunloadHandler(e)
    )
  }
}
</script>

<style lang="less" scoped>
.index {
  height: 100%;
  display: flex;
  flex-direction: column;
  box-sizing: border-box;

  .index__header {
    display: flex;
    box-sizing: border-box;
    padding-top: 20px;

    /deep/ .index__header_radio--size {
      margin-left: 10px;
      .el-radio-button__inner {
        width: 150px;
        border-radius: 0 !important;
      }
    }
    .index__header_btn {
      text-align: right;
      flex: 1;
      margin-right: 40px;
      button {
        width: 150px;
      }
    }
  }
  .index__content {
    box-sizing: border-box;
    border: 2px solid #409eff;
    padding: 10px;
    border-radius: 5px;
    flex: 1;
    display: flex;
    flex-direction: column;
    .index__content_header {
      display: flex;
      box-sizing: border-box;

      .index__content_header--btn {
        width: 100px;
        margin-right: 20px;
      }
      .index__content_header--input {
        width: 400px;
      }
    }
    .index__content_center {
      margin-top: 20px;
    }
    .index__content_bottom {
      display: flex;
      overflow-y: auto;
      flex-wrap: wrap;
      padding: 5px;
      min-height: 300px;
      margin-top: 20px;
      .no-data {
        line-height: 60px;
        color: #909399;
        text-align: center;
        flex: 1;
      }
      .index__content--item {
        box-sizing: border-box;
        width: 120px;
        height: 120px;
        position: relative;
        margin-right: 20px;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 10px;
        margin-bottom: 20px;
        img {
          width: 100px;
          height: 80px;
        }
        &:hover {
          .index__content--edit {
            display: block;
            background: #3c3c3c;
            position: absolute;
            left: 0;
            bottom: 0;
            width: 100%;
            height: 25px;
            text-align: center;
            color: #fff;
            font-size: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
          }
        }
        .index__content--name {
          height: 25px;
          line-height: 25px;
          text-align: center;
          color: #000;
          font-size: 15px;
          overflow: hidden;
          white-space: nowrap;
          /* 文字超出宽度则显示ellipsis省略号 */
          text-overflow: ellipsis;
          width: 100%;
        }
        .index__content--edit {
          display: none;
        }
      }
    }
  }
}
</style>
