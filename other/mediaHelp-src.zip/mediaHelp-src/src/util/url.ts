/*
 * @Author: your name
 * @Date: 2020-10-30 19:09:06
 * @LastEditTime: 2021-04-05 17:41:27
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /wolfberry-platform/src/util/url.ts
 */
let Domain: string = 'http://127.0.0.1:9002'

export { Domain }
