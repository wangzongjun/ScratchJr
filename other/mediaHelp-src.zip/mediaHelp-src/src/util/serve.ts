/*
 * @Author: your name
 * @Date: 2020-10-30 19:09:06
 * @LastEditTime: 2021-04-05 17:41:08
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /wolfberry-platform/src/util/serve.ts
 */
import axios from 'axios'
// 创建axios实例
const service = axios.create({
  timeout: 60000, // 请求超时时间,
  method: 'get',
  headers: {
    //'token':getToken("cmsOpsSid"),//业务接口统一在header中添加token
    'Content-Type': 'application/json;charset=UTF-8'
  },
  params: {}
})

//request拦截器
service.interceptors.request.use(
  (config) => {
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// response 拦截器
service.interceptors.response.use(
  (response) => {
    /**
     * code为非20000是抛错 可结合自己业务进行修改
     */
    return response.data
  },
  (error) => {
    console.log(error)
    return Promise.reject(error)
  }
)

export default service
