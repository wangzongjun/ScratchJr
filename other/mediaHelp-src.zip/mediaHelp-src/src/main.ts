/*
 * @Author: your name
 * @Date: 2021-04-05 17:32:43
 * @LastEditTime: 2021-04-05 17:39:34
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /work/education_game/src/main.ts
 */
import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
require('./style/reset.css')
require('./plugins/index')
Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: (h) => h(App)
}).$mount('#app')
