/*
 * @Author: your name
 * @Date: 2020-10-30 19:09:06
 * @LastEditTime: 2021-04-05 17:33:32
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /wolfberry-platform/babel.config.js
 */
const plugins = [
  [
    'component',
    {
      libraryName: 'element-ui',
      styleLibraryName: 'theme-chalk'
    }
  ],
  '@vue/babel-plugin-transform-vue-jsx'
]
module.exports = {
  presets: ['@vue/cli-plugin-babel/preset'],
  plugins
}
