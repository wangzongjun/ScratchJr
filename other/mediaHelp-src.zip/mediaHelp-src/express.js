/*
 * @Author: your name
 * @Date: 2021-04-18 21:48:04
 * @LastEditTime: 2021-04-18 21:55:35
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /education_game/express.js
 */

const express = require('express')
const app = express()
const port = 3000

app.use('/', express.static('dist'))

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})
